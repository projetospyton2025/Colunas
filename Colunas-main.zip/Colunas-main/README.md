# Colunas
Objetivo: Buscar qual numero mais sorteados por coluna sendo se serão 6 colunas, col1, col2, col3, col4, col5, col6
